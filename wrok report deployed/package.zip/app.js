// Namecheap Phusion Passenger Entry Point
console.log('--- Passenger Entry Point (app.js) Active ---');

const startServer = async () => {
  try {
    console.log('Attempting to import server/index.js...');
    await import('./server/index.js');
    console.log('Server module imported successfully');
  } catch (err) {
    console.error('CRITICAL STARTUP ERROR DETECTED:');
    console.error(err);
    // Log stack trace if available
    if (err.stack) console.error(err.stack);
  }
};

startServer();
